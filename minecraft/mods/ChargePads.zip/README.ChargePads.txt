Charge Pads v2.4.1 build 66 (for Minecraft v1.4.7)    -by- Myrathi
------------------------------------------------------------------------------------------

Q. What does this mod do?
A. It provides new IC2 blocks that, when stood upon, will recharge IC2 items that are held
   in your hand or worn (like batpacks or parts of a nanosuit).

Q. How do I install it?
A. You place the ZIP file into the client's (and server's, if SMP) /mods folder.

Q. Do I need anything else to use it?
A. You'll need:
   * For 1.4.7: Forge (build 489+) and IC2 (build 1.115)
   * For 1.4.6: Forge (build 471+) and IC2 (build 1.112)
   * For 1.4.5: Forge (build 428+) and IC2 (build 1.110-111)
   * For 1.4.2: Forge (build 353+) and IC2 (build 1.108)
   * For 1.3.2: Forge (build 297+) and IC2 (build 1.106-107)

Q. How do the pads work?
A. You attach IC2 power into the bottom of a pad (or insert a battery item) and then
   stand on top of it. If a pad has power, it'll emit an electrical field upwards that
   will recharge your items and armour. You can insert upgrade modules to alter pads'
   functionality, too (see below).

Q. How many different pads are there?
A. There are three (3), matching IC2's general tiering system, and they're named around
   technology you'll find in each tier.

   Tier 1: Static Charge Pad
   Tier 2: Crystalizor Charge Pad
   Tier 3: Lapotronic Charge Pad

Q. What sort of upgrades can the pads use?
A. All three (3) pads can accept and use core IC2 upgrade modules, a new efficiency
   upgrade module and Crystalizor and Lapotronic pads can have their emitter projectors
   and fields upgraded via several different modules. Higher tier pads can accept more
   types of upgrade at once and you can only ever use one (1) projector module and
   one (1) field conversion module at most, per pad.

   * Overclocker: increases overall charge rate but also increases energy consumption
   * Efficiency: counteracts overclocker energy consumption plus minor charge ratio bonus
   * Storage: increases maximum energy storage capability
   * Transformer: improves how much EU/t can be handled as input (32 > 128 > 512 > ...)
   * Drain: converts an emitter field to drain items instead of charge them
   * Damage: converts an emitter field to cause damage to anything in the field
   * Armour Priority: causes an emitter field to prioritise armour before held items
   * Proximity: improves the projector, simultaneously recharging items beside the held item
   * Wide-Band: improves the projector, simultaneously recharging every item on the hot-bar
   * Field Expander: improves the projector range, charging things further from the pad

   NOTE: Damage and Drain emitter modules can be turned off via system configuration
         (in the /config folder)

Q. I have lower tier pads and want to upgrade. How can I do that?
A. There are two (2) kits that can upgrade LV and MV pads into the next better. The first
is the Crystalizor Upgrade Kit: it will upgrade a Static pad into a Crystalizor pad. The
second is the Lapotronic Upgrade Kit - requiring a new MFS Upgrade - which will upgrade a
Crystalizor pad into a Lapotronic pad. You can either combine a pad and a kit in a
crafting bench (as a shapeless recipe) or you can simply right-click a kit onto the power
panel of a pad (the bottom) to upgrade it in-place!

   HINT: The pad will keep its existing power AND any items currently charging it!
   NOTE: Upgrading a pad that someone is using may give you a nasty shock! Be careful!
   NOTE: Upgrades can be used on any side via system configuration (in the /config folder)
   NOTE: Upgrade electrocution damage can be altered or turned off via configuration.

Q. Do pads actively require power?
A. Usually. Assuming you have power feeding into the bottom of the pad, it will not only
   receive that power but it will store it for later use, exactly the way a batbox, MFE
   or MFSU would (it's made from one, after all). Right-clicking on a pad will show its
   GUI, which allows you to view the current charge storage, the maximum safe input rate
   and manipulate upgrade modules.

   NOTE: There's no "Out" EU/t rating, as the pad only ever *accepts* power.

Q. Why does the pad run out of power when I'm not charging anything?
A. Creating an electrical field actually takes a small amount of power (it really is a
   very small amount) but if you're not hooked up to a constant source, you can actually
   use up the pad's personal storage, completely. At that point, the field will collapse.

   HINT: Open the GUI while you stand on an unpowered pad and you can see it trickle out!
   NOTE: Some upgrades cause the pad to consume more power per tick. 

Q. Why can't I access the GUI of my pad? Or use a wrench on it?
A. If a pad has a drain or damage emitter conversion upgrade installed, then it also
   restricts access to the internals from anywhere other than the underside of the pad
   (where a power-cable enters it). This is to stop "enemies" from being able to quickly
   access and remove hostile emitter upgrades from a defensive pad before walking onto
   it (not to mention swiftly stealing your expensive modules!). In short: you need to
   activate/wrench the pad from underneath to access the pad and remove modules.

Q. Why doesn't my item/armour charge when I stand on the pad? Why does it lose charge?!
A. There are a few reasons this may happen:
   1) If there's no "electrical field" above the pad, it's not charging anything.
   2) Charge pads can only charge items of appropriate tier: your item's too high-tech!
   3) Normally, a pad will charge held items before starting on armour (this is reversed
      if an armour priority upgrade is installed, charging all armour before items)
   4) If the field looks yellow/orange then it has a drain module installed!
   5) If the field looks red, then it has a damage module installed!

Q. I have a Lapotronic pad and it doesn't charge fast enough! Grr!
A. If you're holding several items (with a proximity or wide-band upgrade installed) or
   wearing multiple chargeable armour items, the electrical field will distribute the
   charge equally between all of them, slowing down the charge rate of individual items.
   High-tier items have a lot of power to recharge, so this can take a noticeable amount
   of time!

   HINT: If you stand just right, you can be in the electrical field of more than one
         pad, at the same time! ;)

   HINT: Pads can be upgraded with overclockers to improve charge rate

   NOTE: If multiple people stand on a pad, the energy is distributed amongst *all* of
         the items in the electrical field! It will not increase the field power as it
		 cannot guarantee proper control with the limited circuitry and may, in fact,
		 cause physical harm!

Q. My pad blew up! Whyyy?!
A. Did you feed the wrong tier of power into it? Like with most IC2 machines: that's bad!

   HINT: Pads can be upgraded with transformer modules to accept higher tiered input

Q. I hopped onto a pad and almost died! Why'd it hurt so much!?
A. Did you drop onto one? Pads are highly complex electrical devices that EMIT electrical
   fields! Jumping on them causes them to discharge more electricity than their systems
   can safely limit. In layman's terms: they give you an electric shock! The more
   advanced the pad: the less abuse they'll withstand (the harder you jump, the bigger a
   shock you'll receive)! Alternatively, if the electrical field is red, then the pad has
   a damage conversion module installed and the emitter causes harm, instead! Ow!

   NOTE: Jump damage and emitter upgrades can be turned off via system configuration
         (in the /config folder)

Q. I tried to move the pad and it electrocuted me! To death! Ooooww!
A. Shocking! Charge pads require proper technical expertise to disable and move. If this
   isn't done properly then the energy they contain will almost certainly discharge into
   the nearby environment in a rather disruptive fashion: this has, in virtually all 
   tests, caused varying levels of physical trauma and, in some cases, death. If you're
   fortunate, and you're standing at a distance, the power field may not actually reach
   you (or won't hurt you quite as much, if it does). More advanced pads can store a
   significantly higher amount of energy and will cause proportionally greater levels of
   pain!

   HINT: Use a wrench!!

   NOTE: Electrocution DOES ignore armour. This is not a bug: it's a design choice! ;)
   NOTE: This can be turned off via system configuration (in the /config folder)

Q. Ok... how do I make the shinies? Err... pads, kits and upgrades?
A. You'll need a 3x3 crafting matrix and increasingly advanced materials and items for
   each type of pad, upgrade kit and module:

   Static Charge Pad       Crystalizor Charge Pad     Lapotronic Charge Pad
      [ ] [ ] [ ]               [ ] [ ] [ ]                [ ] [ ] [ ]
      [R] [S] [R]               [R] [S] [R]                [C] [S] [C]
      [E] [B] [E]               [E] [M] [E]                [A] [U] [A]

  Efficiency Upgrade       Drain Conversion Module   Damage Conversion Module
      [ ] [ ] [ ]               [ ] [ ] [ ]                [ ] [ ] [ ]
      [F] [G] [F]               [D] [D] [D]                [N] [N] [N]
      [I] [A] [I]               [I] [A] [I]                [I] [A] [I]

 Proximity Booster Mod      Wide-Band Booster Mod     Armour Priority Module
      [A] [A] [A]               [A] [@] [A]                [ ] [ ] [ ]
      [^] [P] [^]               [*] [P] [*]                [D] [#] [D]
      [I] [A] [I]               [A] [@] [A]                [I] [@] [I]

 Field Expansion (Alpha)   Field Expansion (Delta)    Field Expansion (Theta)
      [T] [?] [T]               [:] [/] [:]                [$] [^] [$]
      [P] [!] [P]               [P] [A] [P]                [~] [P] [~]
      [T] [?] [T]               [:] [/] [:]                [/] [A] [/]

  Crystalizor Upgrade Kit       MFS Upgrade           Lapotronic Upgrade Kit
      [ ] [W] [ ]         [O] [A] [O]   [ ] [Y] [ ]        [ ] [ ] [ ]
      [ ] [E] [ ]         [O] [Y] [O]   [ ] [U] [ ]        [A] [W] [A]
      [ ] [M] [ ]         [O] [X] [O]   [ ] [ ] [ ]        [C] [+] [C]

            Shapeless:     Crystalizor Charge Pad     Lapotronic Charge Pad
                                  [1] [Z]                    [2] [L]

            1 - Static Charge Pad           T - Neutron Reflector
            2 - Crystalizor Charge Pad      U - MFS Unit
            A - Advanced Circuit            W - Electronic Wrench
            B - BatBox                      X - Advanced Machine
            C - Carbon Plate                Y - Wrench
            D - Glowstone Dust              Z - Crystalizor Upgrade Kit
            E - Electronic Circuit          / - Efficiency Upgrade
            F - RE-Battery (FULL)           + - MFS Upgrade
            G - Glass Fiber Cable           @ - Proximity Booster Mod
            I - 2xIns. Gold Cable           ! - Wide-Band Booster Mod
            L - Lapotronic Upgrade Kit      $ - Thick Neutron Reflector
            M - MFE Unit                    # - Ender Pearl
            N - Near-depleted Uranium Cell  ^ - Overclocker Upgrade
            O - Lapotron Crystal            * - Energy Crystal
            P - Splitter Cable              ? - Detector Cable
            R - Rubber                      : - Field Expansion (Alpha)
            S - Stone Pressure Plate        ~ - Field Expansion (Delta)

Q. I want to know when someone is using my pads!
A. When pads are activated (specifically, when you stand on them), they emit a signal on
   a frequency that affects redstone dust! This signal is emitted from the bottom and all
   four sides of a charge pad with a force similar to that of a redstone repeater (it
   energises the whole block which will, for example, affect dust or lamps connected to
   it). Friction - caused by pressure on the pad - is more than enough for the circuitry
   to produce the signal, so it will be emitted even if the pad contains no power.

Q. Are we done, yet?
A. We are. Enjoy your new Charge Pads!

==========
Change Log
----------
v2.4.1.66 - Configuration files no longer re-save if unmodified.
v2.4.0.64 - Update for Minecraft v1.4.7 and IC2-1.115. GUI redesign and six new emitter modules! (Field Expansion suggestion by DireWolf20)
v2.3.1.61 - Code cleanup. Use IC2 EnergyNet events.
v2.3.0.58 - Update for Minecraft v1.4.6 and IC2-1.112.
v2.2.0.52 - Update for IC2-1.110.
v2.1.1.51 - Separate out GUI elements for high-res texture pack makers.
v2.1.0.49 - Update for Minecraft v1.4.5 and IC2-1.109. Fixed armour drain.
v2.0.2.47 - Fixed shift-clicking to move upgrades to the pad.
v2.0.1.46 - New MFS Upgrade recipe. Wrench ejects inventory. Offensive pads wrench via base.
v2.0.0.45 - Update for Minecraft v1.4.2 and IC2-1.108 (and NEI support)
v1.2.2.43 - Pads now accept IC2 Upgrade Modules + new modules!
v1.1.0.21 - New upgrade kits for existing pads! (suggestion by Monoxide)
v1.0.0.19 - Initial release

==========
[b]ChargePads[/b] is licensed under a 'Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License'.
Appropriate restrictions are waived for the IC2 team as required by their publishing notes.

License: http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_GB
IC2 Notes: http://forum.industrial-craft.net/index.php?page=Thread&threadID=344
Mod Thread: http://bit.ly/ChargePads
